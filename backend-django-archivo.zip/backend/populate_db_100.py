import os
import django
import random
from datetime import date, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.settings')
django.setup()

from usuarios.models import Usuario
from granja.models import LoteCerdos, Cultivo, RegistroPeso, RegistroSalud
from inventario.models import Proveedor, Producto, OrdenCompra, ConsumoAlimento
from finanzas.models import Transaccion
from ventas.models import Cliente, Venta, VentaDetalle

def seed_database():
    print("Starting database population script (populate_db_100.py)...")
    
    # Clean existing data safely if needed, or build on top
    # 1. Users & Admin
    admin_user, _ = Usuario.objects.get_or_create(
        username='admin',
        defaults={
            'email': 'admin@fincalaprimavera.com',
            'first_name': 'Administrador',
            'last_name': 'Principal',
            'rol': 'ADMIN',
            'is_staff': True,
            'is_superuser': True
        }
    )
    if not admin_user.check_password('admin123'):
        admin_user.set_password('admin123')
        admin_user.save()
        
    empleados = []
    for i in range(1, 4):
        emp, _ = Usuario.objects.get_or_create(
            username=f'empleado{i}',
            defaults={
                'email': f'empleado{i}@fincalaprimavera.com',
                'first_name': f'Empleado',
                'last_name': f'Nº {i}',
                'rol': 'EMPLEADO',
                'telefono': f'8888-000{i}'
            }
        )
        if not emp.check_password('emp123'):
            emp.set_password('emp123')
            emp.save()
        empleados.append(emp)

    print("Users created/verified.")

    # 2. Lotes de Cerdos (18 registros)
    razas = ['Yorkshire', 'Duroc', 'Landrake', 'Pietrain', 'Hampshire']
    estados = ['SALUDABLE', 'ENGORDE', 'CRIA', 'DESTETE', 'OBSERVACION', 'REVISION']
    corrales = [f'Corral {c}-{n}' for c in ['A', 'B', 'C'] for n in [1, 2, 3, 4]]
    
    lotes = []
    for i in range(1, 19):
        batch_id = f"LOTE-2026-{i:03d}"
        lote, created = LoteCerdos.objects.get_or_create(
            id_batch=batch_id,
            defaults={
                'fecha_entrada': date(2026, 1, 1) + timedelta(days=i*5),
                'cantidad_inicial': random.randint(20, 50),
                'cantidad_actual': random.randint(15, 45),
                'peso_promedio_inicial': round(random.uniform(8.0, 15.0), 1),
                'peso_actual': round(random.uniform(35.0, 95.0), 1),
                'costo_inicial': random.randint(3000, 12000),
                'raza': random.choice(razas),
                'estado': random.choice(estados),
                'edad_inicial_semanas': random.randint(4, 8),
                'ubicacion': random.choice(corrales),
                'observaciones': f"Lote de engorde de excelente genética {i}."
            }
        )
        lotes.append(lote)
        
        # Registros de peso para cada lote
        for p in range(1, 4):
            RegistroPeso.objects.get_or_create(
                lote=lote,
                peso=round(lote.peso_promedio_inicial + (p * random.uniform(10.0, 20.0)), 1)
            )
            
        # Registros de salud para algunos lotes
        if i % 2 == 0:
            RegistroSalud.objects.get_or_create(
                lote=lote,
                fecha=lote.fecha_entrada + timedelta(days=10),
                defaults={
                    'descripcion': 'Vacunación y Desparasitación Preventiva',
                    'tratamiento': 'Dosis 2ml Ivermectina + Parvovirus',
                    'responsable': random.choice(empleados).username
                }
            )

    print(f"Lotes de cerdos (18) and health/weight records generated.")

    # 3. Cultivos (Papaya y Plátano)
    cultivos = []
    c1, _ = Cultivo.objects.get_or_create(
        tipo='PAPAYA',
        area_manzanas=5.5,
        defaults={
            'fecha_siembra': date(2026, 1, 15),
            'estado': 'COSECHA',
            'cantidad_estimada': 12000
        }
    )
    c2, _ = Cultivo.objects.get_or_create(
        tipo='PLATANO',
        area_manzanas=8.0,
        defaults={
            'fecha_siembra': date(2026, 2, 1),
            'estado': 'CRECIMIENTO',
            'cantidad_estimada': 25000
        }
    )
    c3, _ = Cultivo.objects.get_or_create(
        tipo='PAPAYA',
        area_manzanas=3.0,
        defaults={
            'fecha_siembra': date(2025, 10, 10),
            'estado': 'FINALIZADO',
            'cantidad_estimada': 8000
        }
    )
    cultivos.extend([c1, c2, c3])
    print("Cultivos created.")

    # 4. Proveedores (4) & Productos en Inventario (20)
    proveedores_data = [
        ("AgroInsumos del Norte", "Carlos Mendoza", "8822-1100", "contacto@agroinsumos.com"),
        ("Veterinaria La Purísima", "Dra. Sofía Rivas", "8933-4455", "ventas@purisima.com"),
        ("Distribuidora Agrícola Central", "Jorge López", "8711-2233", "jlopez@distcentral.com"),
        ("Ferretería y Herramientas El Campesino", "Ramon Perez", "8655-9900", "info@elcampesino.com")
    ]
    proveedores = []
    for prov_name, contact, phone, email in proveedores_data:
        p, _ = Proveedor.objects.get_or_create(
            nombre=prov_name,
            defaults={'contacto': contact, 'telefono': phone, 'email': email}
        )
        proveedores.append(p)

    productos_data = [
        ("Alimento Iniciador Cerdos 25kg", "ALIMENTO", 50, 10, 450.00, proveedores[0]),
        ("Alimento Crecimiento Cerdos 40kg", "ALIMENTO", 120, 15, 680.00, proveedores[0]),
        ("Alimento Engorde Cerdos 50kg", "ALIMENTO", 200, 20, 750.00, proveedores[0]),
        ("Alimento Gestación 40kg", "ALIMENTO", 30, 8, 620.00, proveedores[0]),
        ("Suplemento Vitamínico A-D3-E", "ALIMENTO", 25, 5, 320.00, proveedores[1]),
        ("Vacuna Parvovirus 50 Dosis", "MEDICINA", 12, 3, 1100.00, proveedores[1]),
        ("Ivermectina 500ml", "MEDICINA", 8, 2, 850.00, proveedores[1]),
        ("Antibiótico Penicilina 250ml", "MEDICINA", 15, 4, 480.00, proveedores[1]),
        ("Desinfectante Granja Galón", "MEDICINA", 30, 5, 290.00, proveedores[1]),
        ("Complejo B Inyectable", "MEDICINA", 20, 5, 210.00, proveedores[1]),
        ("Comedero Plástico Cerdos", "HERRAMIENTA", 40, 5, 550.00, proveedores[3]),
        ("Bebedero Chupete Acero Inox", "HERRAMIENTA", 100, 10, 120.00, proveedores[3]),
        ("Manguera Industrial 100m", "HERRAMIENTA", 5, 2, 1450.00, proveedores[3]),
        ("Bomba de Fumigación 20L", "HERRAMIENTA", 4, 2, 2100.00, proveedores[3]),
        ("Botas de Hule Talla 42", "HERRAMIENTA", 15, 3, 420.00, proveedores[3]),
        ("Guantes de Nitrilo (Caja 100)", "HERRAMIENTA", 25, 5, 180.00, proveedores[3]),
        ("Bolsas Cosecha Papaya 100u", "OTROS", 80, 10, 250.00, proveedores[2]),
        ("Cajas Plásticas Cosecha", "OTROS", 150, 20, 380.00, proveedores[2]),
        ("Cinta de Amarre Banano/Plátano", "OTROS", 60, 10, 140.00, proveedores[2]),
        ("Fertilizante Foliar 20-20-20 5kg", "OTROS", 18, 4, 890.00, proveedores[2]),
    ]

    productos = []
    for nom, cat, cant, st_min, prec, prov in productos_data:
        prod, _ = Producto.objects.get_or_create(
            nombre=nom,
            defaults={
                'categoria': cat,
                'cantidad': cant,
                'stock_minimo': st_min,
                'precio_unitario': prec,
                'proveedor': prov
            }
        )
        productos.append(prod)

    print(f"Productos (20) and Proveedores (4) generated.")

    # Consumo de Alimento (Asociando Lotes con Alimentos)
    alimentos = [p for p in productos if p.categoria == 'ALIMENTO']
    for lote in lotes[:10]:
        alimento_sel = random.choice(alimentos)
        cant_consumida = random.randint(5, 15)
        monto = cant_consumida * float(alimento_sel.precio_unitario)
        ConsumoAlimento.objects.get_or_create(
            lote=lote,
            alimento=alimento_sel,
            cantidad=cant_consumida,
            defaults={'monto_total': monto}
        )

    # 5. Clientes (10 registros)
    clientes_names = [
        "Embutidos y Carnes La Selecta",
        "Mercado Central Distribuidora",
        "Supermercados del Campo S.A.",
        "Restaurante El Rincón Agrícola",
        "Carnicería San José",
        "Distribuidora AgroFrutas",
        "Don Antonio Rodríguez",
        "Comercializadora de Granos y Carnes",
        "Frutería Fresca La Primavera",
        "Hotel y Gourmet El Solar"
    ]
    clientes = []
    for idx, c_name in enumerate(clientes_names, 1):
        cli, _ = Cliente.objects.get_or_create(
            nombre=c_name,
            defaults={
                'telefono': f'8700-100{idx}',
                'email': f'cliente{idx}@empresa.com',
                'direccion': f'Barrio Central, Managua / Rivas'
            }
        )
        clientes.append(cli)

    print(f"Clientes (10) generated.")

    # 6. Ventas (30) y Detalles de Venta (58)
    ventas = []
    detalles_count = 0
    metodos = ['EFECTIVO', 'TRANSFERENCIA', 'OTRO']
    
    for v_idx in range(1, 31):
        cliente_sel = random.choice(clientes)
        venta, _ = Venta.objects.get_or_create(
            id=v_idx,
            defaults={
                'cliente': cliente_sel,
                'metodo_pago': random.choice(metodos),
                'pagado': True,
                'total': 0.00
            }
        )
        ventas.append(venta)
        
        # Generar de 1 a 3 detalles por venta
        total_venta = 0.0
        num_detalles = random.randint(1, 3)
        for _ in range(num_detalles):
            detalles_count += 1
            tipo_item = random.choice(['LOTES', 'PRODUCTOS', 'CULTIVOS'])
            if tipo_item == 'LOTES':
                lote_sel = random.choice(lotes)
                cant = random.randint(1, 5)
                prec = float(lote_sel.costo_inicial / lote_sel.cantidad_inicial) * 1.4 if lote_sel.cantidad_inicial > 0 else 2500.0
                subt = round(cant * prec, 2)
                VentaDetalle.objects.create(
                    venta=venta,
                    lote_cerdos=lote_sel,
                    cantidad=cant,
                    precio_unitario=prec,
                    subtotal=subt
                )
                total_venta += subt
            elif tipo_item == 'PRODUCTOS':
                prod_sel = random.choice(productos)
                cant = random.randint(1, 10)
                prec = float(prod_sel.precio_unitario)
                subt = round(cant * prec, 2)
                VentaDetalle.objects.create(
                    venta=venta,
                    producto=prod_sel,
                    cantidad=cant,
                    precio_unitario=prec,
                    subtotal=subt
                )
                total_venta += subt
            else:
                cult_sel = random.choice(cultivos)
                cant = random.randint(50, 500)
                prec = 15.0 if cult_sel.tipo == 'PAPAYA' else 8.0
                subt = round(cant * prec, 2)
                VentaDetalle.objects.create(
                    venta=venta,
                    cultivo=cult_sel,
                    cantidad=cant,
                    precio_unitario=prec,
                    subtotal=subt
                )
                total_venta += subt
                
        venta.total = total_venta
        venta.save()

    print(f"Ventas (30) and VentaDetalles ({detalles_count}) generated.")

    # 7. Transacciones Financieras (95 registros)
    transacciones_count = 0
    # Generar ingresos basados en ventas y otros rubros
    for v in ventas:
        Transaccion.objects.create(
            tipo='INGRESO',
            descripcion=f"Ingreso por Venta #{v.id} a {v.cliente.nombre}",
            monto=v.total,
            fecha=date(2026, 1, 1) + timedelta(days=v.id*3)
        )
        transacciones_count += 1
        
    # Generar egresos por compras, alimentos, nómina, servicios
    egresos_desc = [
        "Pago de Nómina quincenal personal de campo",
        "Compra de insumos agrícolas a AgroInsumos del Norte",
        "Mantenimiento preventivo de tractor y galpones",
        "Pago de energía eléctrica y combustible generador",
        "Adquisición de alimentos e iniciadores cerdos",
        "Pago de servicios veterinarios especializados",
        "Flete y transporte de cosecha Papaya a mercado"
    ]
    
    for i in range(1, 66):
        Transaccion.objects.create(
            tipo='EGRESO',
            descripcion=random.choice(egresos_desc),
            monto=round(random.uniform(1500.0, 18000.0), 2),
            fecha=date(2026, 1, 1) + timedelta(days=i*2)
        )
        transacciones_count += 1

    total_records = (
        Usuario.objects.count() +
        LoteCerdos.objects.count() +
        Cultivo.objects.count() +
        RegistroPeso.objects.count() +
        RegistroSalud.objects.count() +
        Proveedor.objects.count() +
        Producto.objects.count() +
        ConsumoAlimento.objects.count() +
        Cliente.objects.count() +
        Venta.objects.count() +
        VentaDetalle.objects.count() +
        Transaccion.objects.count()
    )

    print("==================================================")
    print(f"SUCCESS: Database seeded successfully!")
    print(f"Total Database Records Created/Active: {total_records}")
    print("==================================================")

if __name__ == '__main__':
    seed_database()
