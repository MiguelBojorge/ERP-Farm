from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import Usuario

class UsuariosTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = Usuario.objects.create_user(
            username="user_test",
            password="Password123!",
            email="user@test.com",
            rol="EMPLEADO"
        )

    def test_user_creation(self):
        self.assertEqual(self.user.username, "user_test")
        self.assertEqual(self.user.rol, "EMPLEADO")

    def test_login_jwt(self):
        response = self.client.post('/api/auth/login/', {
            'username': 'user_test',
            'password': 'Password123!'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)
