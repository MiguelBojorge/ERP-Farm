from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from datetime import date
from .models import Cliente, Venta, VentaDetalle
from inventario.models import Producto, Proveedor

class VentasTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.cliente = Cliente.objects.create(
            nombre="Cliente Test",
            telefono="8888-0000",
            email="test@cliente.com"
        )
        self.proveedor = Proveedor.objects.create(nombre="Prov Test")
        self.producto = Producto.objects.create(
            nombre="Prod Venta Test",
            categoria="OTROS",
            cantidad=100,
            stock_minimo=10,
            precio_unitario=150.00,
            proveedor=self.proveedor
        )
        self.venta = Venta.objects.create(
            cliente=self.cliente,
            metodo_pago="EFECTIVO",
            pagado=True,
            total=1500.00
        )
        self.detalle = VentaDetalle.objects.create(
            venta=self.venta,
            producto=self.producto,
            cantidad=10,
            precio_unitario=150.00
        )

    def test_venta_subtotal(self):
        self.assertEqual(self.detalle.subtotal, 1500.00)

    def test_download_factura_pdf(self):
        response = self.client.get(f'/api/ventas/{self.venta.id}/download_factura/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response['Content-Type'], 'application/pdf')
