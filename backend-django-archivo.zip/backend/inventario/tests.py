from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from datetime import date
from .models import Proveedor, Producto, OrdenCompra, ConsumoAlimento
from granja.models import LoteCerdos

class InventarioTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.proveedor = Proveedor.objects.create(
            nombre="Proveedor Test",
            contacto="Juan Perez",
            telefono="8888-9999",
            email="juan@test.com"
        )
        self.producto = Producto.objects.create(
            nombre="Alimento Concentrado Test",
            categoria="ALIMENTO",
            cantidad=50,
            stock_minimo=10,
            precio_unitario=500.00,
            proveedor=self.proveedor
        )
        self.lote = LoteCerdos.objects.create(
            id_batch="LOTE-INV-01",
            fecha_entrada=date(2026, 1, 1),
            cantidad_inicial=10,
            cantidad_actual=10,
            peso_promedio_inicial=10,
            costo_inicial=2000,
            raza="Duroc"
        )

    def test_producto_stock(self):
        self.assertEqual(self.producto.cantidad, 50)
        self.assertEqual(self.producto.stock_minimo, 10)
        self.assertFalse(self.producto.cantidad < self.producto.stock_minimo)

    def test_consumo_alimento(self):
        consumo = ConsumoAlimento.objects.create(
            lote=self.lote,
            alimento=self.producto,
            cantidad=5,
            monto_total=2500.00
        )
        self.assertEqual(consumo.monto_total, 2500.00)

    def test_api_productos(self):
        response = self.client.get('/api/productos/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
