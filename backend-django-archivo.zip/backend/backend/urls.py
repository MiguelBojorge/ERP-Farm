from django.http import JsonResponse
from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from granja.views import LoteCerdosViewSet, CultivoViewSet, RegistroSaludViewSet
from inventario.views import ProductoViewSet, ProveedorViewSet, OrdenCompraViewSet, ConsumoAlimentoViewSet
from finanzas.views import TransaccionViewSet
from ventas.views import VentaViewSet, ClienteViewSet
from usuarios.views import UsuarioViewSet, MeView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

def api_root(request):
    return JsonResponse({
        "message": "Bienvenido al API de Finca la Primavera",
        "endpoints": {
            "admin": "/admin/",
            "api": "/api/",
            "auth": "/api/auth/login/",
            "me": "/api/auth/me/"
        }
    })

router = routers.DefaultRouter()
router.register(r'lotes-cerdos', LoteCerdosViewSet)
router.register(r'cultivos', CultivoViewSet)
router.register(r'registros-salud', RegistroSaludViewSet)
router.register(r'productos', ProductoViewSet)
router.register(r'proveedores', ProveedorViewSet)
router.register(r'ordenes-compra', OrdenCompraViewSet)
router.register(r'consumos-alimento', ConsumoAlimentoViewSet)
router.register(r'transacciones', TransaccionViewSet)
router.register(r'ventas', VentaViewSet)
router.register(r'clientes', ClienteViewSet)
router.register(r'usuarios', UsuarioViewSet)

urlpatterns = [
    path('', api_root),
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/auth/me/', MeView.as_view(), name='auth_me'),
    path('api/auth/', include('allauth.urls')), # Structure for Google Auth
]
