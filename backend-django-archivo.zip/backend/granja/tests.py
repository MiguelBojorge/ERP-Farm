from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from datetime import date
from .models import LoteCerdos, Cultivo, RegistroPeso, RegistroSalud

class GranjaModelTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.lote = LoteCerdos.objects.create(
            id_batch="LOTE-TEST-01",
            fecha_entrada=date(2026, 1, 1),
            cantidad_inicial=20,
            cantidad_actual=20,
            peso_promedio_inicial=12.5,
            peso_actual=45.0,
            costo_inicial=5000.00,
            raza="Yorkshire",
            estado="SALUDABLE",
            edad_inicial_semanas=6,
            ubicacion="Corral A-1"
        )
        self.cultivo = Cultivo.objects.create(
            tipo="PAPAYA",
            area_manzanas=4.0,
            fecha_siembra=date(2026, 2, 1),
            estado="CRECIMIENTO",
            cantidad_estimada=10000
        )

    def test_lote_creation(self):
        self.assertEqual(self.lote.id_batch, "LOTE-TEST-01")
        self.assertEqual(self.lote.cantidad_actual, 20)
        self.assertEqual(str(self.lote), "Lote LOTE-TEST-01 - Yorkshire")

    def test_registro_peso(self):
        peso = RegistroPeso.objects.create(lote=self.lote, peso=50.0)
        self.assertEqual(peso.lote.historial_pesos.count(), 1)

    def test_registro_salud(self):
        salud = RegistroSalud.objects.create(
            lote=self.lote,
            fecha=date(2026, 1, 10),
            descripcion="Vacuna Fiebre Porcina",
            tratamiento="2ml por vía intramuscular",
            responsable="Dr. Lopez"
        )
        self.assertEqual(salud.lote.registros_salud.count(), 1)

    def test_api_lotes_list(self):
        response = self.client.get('/api/lotes-cerdos/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data), 1)

    def test_api_cultivos_list(self):
        response = self.client.get('/api/cultivos/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
