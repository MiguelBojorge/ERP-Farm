from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status
from .models import Transaccion

class FinanzasTestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.ingreso = Transaccion.objects.create(
            tipo='INGRESO',
            descripcion='Venta de prueba',
            monto=15000.00
        )
        self.egreso = Transaccion.objects.create(
            tipo='EGRESO',
            descripcion='Compra de alimento prueba',
            monto=5000.00
        )

    def test_transacciones_balance(self):
        ingresos = sum(t.monto for t in Transaccion.objects.filter(tipo='INGRESO'))
        egresos = sum(t.monto for t in Transaccion.objects.filter(tipo='EGRESO'))
        balance = ingresos - egresos
        self.assertEqual(balance, 10000.00)

    def test_api_transacciones(self):
        response = self.client.get('/api/transacciones/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)
